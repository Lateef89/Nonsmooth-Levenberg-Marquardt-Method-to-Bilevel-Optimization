function w=fun(x,y,keyf,keyxy)
% This file provides all functions defining the inverse transportation problem 
% from Mehlitz2022

n = 5; l = 7; m = n*l; p = n+l+m;

% generate transportation matrix blocks T1 (offer constraints) 
% and T2 (demand constraints)

T1 = zeros(n,n*l);
i = 0;

while i<n
    i = i+1;
    T1(i,:)=[zeros(1,(i-1)*l),ones(1,l),zeros(1,(n-i)*l)];
end

T2 = zeros(l,n*l);
j = 0;

while j<n
    j=j+1;
    T2(1:l,(j-1)*l+1:j*l)=eye(l);
end


% %load some data (c, dem, yo) for setting n=5; k=7
% load('Results_InverseTransportation_Setting');

c = [ 0.5757, 0.8423, 0.4997, 0.4390, 0.1491, 0.0283, 0.7567, ...
      0.7961, 0.2936, 0.1152, 0.3751, 0.8289, 0.8418, 0.6652, ...
      0.9601, 0.9431, 0.1127, 0.6483, 0.4808, 0.0665, 0.8978, ...
      0.4972, 0.7713, 0.0604, 0.2625, 0.6511, 0.1336, 0.6385, ...
      0.3849, 0.7657, 0.6529, 0.3815, 0.3000, 0.3401, 0.9189]';

dem = [5;5;5;10;3;9;1];

yo = [ -0.0032,  0.0053, -0.0031,  0.0024,  2.9991,  4.5902,  0.0020, ...
        0.0020,  5.0030,  1.5969, -0.0001,  0.0040,  0.0078,  0.9911, ...
       -0.0080,  0.0030,  3.2053,  0.0098, -0.0075,  4.3973,  0.0035, ...
       -0.0025,  0.0073,  0.1958,  7.3927,  0.0035, -0.0059,  0.0074, ...
        5.0050, -0.0016, -0.0100,  2.5930, -0.0045,  0.0074,  0.0020 ]';


if nargin<4
    switch keyf
        case 'F'; w = 0.5*norm(y - yo)^2;
        %case 'F'; w = 0.0005*norm(x)^2 + 0.5*norm(y - yo)^2;    %    regularized variant
        case 'G'; w = [-x; ones(1,l)*dem-ones(1,n)*x];
        case 'f'; w = c'*y; 
        case 'g'; w = [-x+T1*y; dem-T2*y; -y];  
    end    
else
    switch keyf
    case 'F'
        switch keyxy
            case 'x' ; w = zeros(n,1);         
            case 'y' ; w = y-yo;    
            case 'xx'; w = zeros(n,n);
            case 'xy'; w = zeros(m,n);
            case 'yy'; w = eye(m);
%             case 'x' ; w = 0.001*x;         
%             case 'y' ; w = y-yo;    
%             case 'xx'; w = 0.001*eye(n);
%             case 'xy'; w = zeros(m,n);
%             case 'yy'; w = eye(m);
        end 
    case 'G'  
        switch keyxy            
            case 'x' ; w = [(-1)*eye(n);(-1)*ones(1,n)];    
            case 'y' ; w = zeros(n+1,m);  
            case 'xx'; w = zeros(n*(n+1),n);
            case 'xy'; w = zeros(m*(n+1),n);
            case 'yy'; w = zeros(m*(n+1),m);
        end           
	case 'f'    
        switch keyxy
            case 'x' ; w = zeros(n,1);    
            case 'y' ; w = c;         
            case 'xx'; w = zeros(n,n);
            case 'xy'; w = zeros(m,n);
            case 'yy'; w = zeros(m,m);
        end           
	case 'g'   
        switch keyxy
            case 'x' ; w = [(-1)*eye(n); zeros(l,n); zeros(m,n)];   
            case 'y' ; w = [T1;(-1)*T2;(-1)*eye(m)];   
            case 'xx'; w = zeros(n*p,n);
            case 'xy'; w = zeros(m*p,n);
            case 'yy'; w = zeros(m*p,m);
        end        
   end   
end
end


