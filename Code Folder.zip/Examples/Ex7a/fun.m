function w=fun(x,y,keyf,keyxy)
% This file provides all functions defining LamparielloSagratella2017c problem 
% and their first and second order derivatives.
%    F(x,y)= (x-8)^2+(y-9)^2
%    G(x,y)= -x
%    f(x,y)= (y-3)^2
%    g(x,y)= -x+y^2

if nargin<4
    switch keyf
    case 'F'; w = (x-8)^2+(y-9)^2;
    case 'G'; w = -x;
    case 'f'; w = (y-3)^2; 
    case 'g'; w = -x+y^2;  
    end    
else
    switch keyf
    case 'F'
        switch keyxy
        case 'x' ; w = 2*(x-8);         
        case 'y' ; w = 2*(y-9);    
        case 'xx'; w = 2;
        case 'xy'; w = 0;
        case 'yy'; w = 2;
        end 
    case 'G'  
        switch keyxy            
        case 'x' ; w = -1;    
        case 'y' ; w = 0;      
        case 'xx'; w = 0;
        case 'xy'; w = 0;
        case 'yy'; w = 0;
        end           
	case 'f'    
        switch keyxy
        case 'x' ; w = 0;    
        case 'y' ; w = 2*(y-3);         
        case 'xx'; w = 0;
        case 'xy'; w = 0;
        case 'yy'; w = 2;
        end           
	case 'g'   
        switch keyxy
        case 'x' ; w = -1;    
        case 'y' ; w = 2*y;        
        case 'xx'; w = 0;
        case 'xy'; w = 0;
        case 'yy'; w = 2;
        end        
   end   
end
end


