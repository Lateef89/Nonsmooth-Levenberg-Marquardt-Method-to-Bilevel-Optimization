
clear;
clc;

problem = {'LampSag2017c','Ex7a','Transport'};
pro = 3;
%dim = [1 2 1 3]; 
%dim = [1 1 1 1];
n = 5; l = 7; m = n*l; p = n+l+m;
nx = 5; ny = n*l; nG = n+1; ng = n+l+n*l;
dim = [nx, ny, nG, ng];
k=0;   
for i = 1:500
pars.xy =  ones(dim(1)+dim(2),1);
filename2 = 'testdata2.xlsx';
 xx = rand(nx,1);
yy = rand(ny,1);
 
sheet = 1;
k = k+1;
xlrange = xlRange(1,k);
xlswrite(filename2,xx',sheet,xlrange);
xlrange = xlRange(8,k);
xlswrite(filename2,yy',sheet,xlrange);
probname = problem{pro};
addpath(strcat('BOLIBExample/',probname)); 
xlrange = xlRange(1,k);
fprintf('Method 1_LM: i = %2d', i); 
[w,xi,iter,lm_iter,lm_iter_part,term,err1] = Method1_LM(dim,pars,xlrange,xx,yy);
xlrange = xlRange(8,k);
fprintf('Method 1_Res: i = %2d\n', i);
[w_FB_res,xi_FB_res,iter_FB_res,lm_iter_FB,lm_iter_FB_part,term_FB_res,err2] = Method1_LM_FB_residual(dim,pars,xlrange,xx,yy);
xlrange = xlRange(15,k);
fprintf('Method 2_LM: i = %2d',i); 
[w,xi,iter,lm_iter,lm_iter_part,term,err3] = Method2_LM(dim,pars,xlrange,xx,yy);
xlrange = xlRange(22,k);
fprintf('Method 2_Res: i = %2d\n',i); 
[w_FB_res,xi_FB_res,iter_FB_res,lm_iter_FB,lm_iter_FB_part,term_FB_res,err4] = Method2_LM_FB_residual(dim,pars,xlrange,xx,yy);
xlrange = xlRange(29,k);
fprintf('Method 3_LM: i = %2d',i); 
[w,xi,iter,lm_iter,lm_iter_part,term,err5] = Method3_LM(dim,pars,xlrange,xx,yy);
xlrange = xlRange(36,k);
fprintf('Method 2_Res: i = %2d\n',i); 
[w_FB_res,xi_FB_res,iter_FB_res,lm_iter_FB,lm_iter_FB_part,term_FB_res,err6] = Method3_LM_FB_residual(dim,pars,xlrange,xx,yy);

%n1 = 1:numel(err1);
%n2 = 1:numel(err2);
%n3 = 1:numel(err3);
%n4 = 1:numel(err4);
%n5 = 1:numel(err5);
%n6 = 1:numel(err6);

%figure(i)
%plot(n1,err1,'-b','LineWidth', 2);
%hold on
%plot(n2,err2,'-r','LineWidth', 2);
%plot(n3,err3,'-cy','LineWidth', 2);
%plot(n4,err4,'-m','LineWidth', 2);
%plot(n5,err5,'-k','LineWidth', 2);
%plot(n6,err6,'-g','LineWidth', 2);
%hold off
%    set(gca,'YScale','log');
%    xlabel('Number of iterations');
%    ylabel('\|value_{k}\|^2'); %\|H(z^{k},\xi^{k})\|^2 + \|\phi_{FB}(G(z^{k},-\xi^{k})\|^2
%    legend('Algorithm 4.5 (Para)','Algorithm 4.10 (Para)','Algorithm 4.5 (Var 1)','Algorithm 4.10 (Var 1)',...
%        'Algorithm 4.5 (Var 2)', 'Algorithm 4.5 (Var 2)'); %,'Location','BestOutside'
%    title('Case{i}')
    

%fprintf('min-residual: %2d Iterations,  %2d full LM-steps, ',iter,lm_iter);
%fprintf('%2d partial LM-steps, termination due to %2d\n',lm_iter_part,term);
%fprintf('FB-residual: %2d Iterations,  %2d full LM-steps, ',iter_FB_res,lm_iter_FB);
%fprintf('%2d partial LM-steps, termination due to %2d\n',lm_iter_FB_part,term_FB_res);
%fprintf('pure FB-LM: %2d Iterations,  termination due to %2d\n',iter_FB_pure,term_FB_pure);

   
end