function [val,D] = G(X,pars)
dim = pars.dim;
dim0   = [dim(1) dim(2) 1];
num    = [dim0(1) zeros(1,3)];
for i=2:3
num(i) = num(i-1)+dim0(i);
end

x     = X(1: num(1),:);
y     = X(num(1)+1:num(2),:);

g   = fun(x,y,'g');
gx  = fun(x,y,'g','x');
gy  = fun(x,y,'g','y');

G   = fun(x,y,'G');
Gx  = fun(x,y,'G','x');
Gy  = fun(x,y,'G','y');

gz  = zeros(dim(4),1);
Gz  = zeros(dim(3),1);


  if dim(3)>0  && dim(4)>0
    val = [g; G; g];
  elseif dim(3)==0 && dim(4)>0
      val = [g; g];
  elseif dim(3)>0 && dim(4)==0
      val = G;
  else
      val = [];
  end
   
  if dim(3)>0 && dim(4)>0   
    D   = [gx, gy gz;
           Gx, Gy Gz;
           gx, gy gz];
  elseif dim(3)==0 && dim(4)>0
    D   = [gx, gy, gz;
           gx, gy, gz];
  elseif dim(3)>0 && dim(4) ==0
    D   = [Gx, Gy, Gz];
  else
    D   = [];
  end

end
