function [val,Dw,Dxi] = H(X,xi,pars)
dim    = pars.dim;
dim0   = [dim(1) dim(2) 1];
dim1   = [dim(4) dim(3) dim(4)];
num    = [dim0(1) zeros(1,3)];
numm   = [dim1(1) ones(1,3)];
for i=2:3
num(i) = num(i-1)+dim0(i);
end
for j=2:3
numm(j) = numm(j-1)+dim1(j);    
end


 
x     = X(1: num(1),:);
y     = X(num(1)+1:num(2),:);
lam   = X(num(2)+1:num(3),:);
bet     = xi(1: numm(1),:);
alp     = xi(numm(1)+1:numm(2),:);
bet2     = xi(numm(2)+1:numm(3),:);



Gxyx  = fun(x,y,'G','x');
Gxyy  = fun(x,y,'G','y');
gxyx  = fun(x,y,'g','x');
gxyy  = fun(x,y,'g','y');
 
 
JLx  = fun(x,y,'F','x') + Gxyx'*alp + ...
       gxyx'*bet - lam^2*gxyx'*bet2;       
JLy  = fun(x,y,'F','y') + Gxyy'*alp + ...
       gxyy'*bet - lam^2*gxyy'*bet2;
   
Jly  = fun(x,y,'f','y') + gxyy'*bet2;

val  = [JLx; JLy; Jly];



JLxx = fun(x,y,'F','xx')  +  JuTf(alp,fun(x,y,'G','xx'))   + ...
       + JuTf(bet,fun(x,y,'g','xx')) - lam^2*JuTf(bet2,fun(x,y,'g','xx'));
JLxy = fun(x,y,'F','xy')  +  JuTf(alp,fun(x,y,'G','xy'))   + ...
       + JuTf(bet,fun(x,y,'g','xy')) - lam^2*JuTf(bet2,fun(x,y,'g','xy'));
JLxu = fun(x,y,'G','x');
JLxv = fun(x,y,'g','x');
JLxw = -lam^2*fun(x,y,'g','x');
JLxz = -2*lam*bet2'*fun(x,y,'g','x');



JLyy = fun(x,y,'F','yy')  +  JuTf(alp,fun(x,y,'G','yy'))   + ...
       + JuTf(bet,fun(x,y,'g','yy')) - lam^2*JuTf(bet2,fun(x,y,'g','yy'));
JLyu = fun(x,y,'G','y'); 
JLyv = fun(x,y,'g','y'); 
JLyw = -lam^2*fun(x,y,'g','y');
JLyz = -2*lam*bet2'*fun(x,y,'g','y');


Jlxy = fun(x,y,'f','xy') + JuTf(bet2,fun(x,y,'g','xy'));
Jlyy = fun(x,y,'f','yy') + JuTf(bet2,fun(x,y,'g','yy'));
Jlyu = zeros(dim(2),dim(3));
Jlyv = zeros(dim(2),dim(4));
Jlyw = fun(x,y,'g','y');
Jlyz = zeros(dim(2),1);

Dw   = [JLxx, JLxy', JLxz'; ...
        JLxy, JLyy,  JLyz'; ...
        Jlxy, Jlyy,  Jlyz];

    
Dxi  = [JLxv' JLxu' JLxw';
        JLyv' JLyu' JLyw';
        Jlyv  Jlyu  Jlyw']; 

end
%% ========================================================================
function Juf = JuTf(u,Jf) 
    if ~isempty(Jf)
        nG    = size(u,1);
        nx    = size(Jf,2);
        ny    = size(Jf,1)/nG;
        Juf   = zeros(ny,nx);
        for i = 1:nG
        Juf   = Juf+ u(i)*ones(ny,nx).*Jf( (1+(i-1)*ny):(i*ny),: );
        end
    else
        Juf   = 0;
    end
end