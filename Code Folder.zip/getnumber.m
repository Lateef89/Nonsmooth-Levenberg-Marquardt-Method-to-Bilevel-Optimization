function num=getnumber(dim)
dim0   = [dim(1) dim(2) dim(3) dim(4) dim(4) 1];
num    = [dim0(1) zeros(1,6)];
for i=2:6
num(i) = num(i-1)+dim0(i);
end
end