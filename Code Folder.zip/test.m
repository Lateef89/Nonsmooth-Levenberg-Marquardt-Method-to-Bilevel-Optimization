
clear;
clc;

problem = {'LampSag2017c','Ex7a','Transport'};
pro = 3;
%dim = [1 2 1 3]; 
%dim = [1 1 1 1];
n = 5; l = 7; m = n*l; p = n+l+m;
nx = 5; ny = n*l; nG = n+1; ng = n+l+n*l;
dim = [nx, ny, nG, ng];
k=0;   
for i = 1
pars.xy =  ones(dim(1)+dim(2),1);
filename1 = 'testdata1.xlsx';
%filename2 = 'testdatay.xlsx';
xx = rand(nx,1);
yy = rand(ny,1);
%zz = 0.9*[0.8312	0.9223	0.3270	0.8041	0.5383	0.4633	0.8208	0.9519	0.0763	0.7087	0.2349	0.3989	0.2681	0.8325	0.9954	0.6498	0.7040	0.9323	0.6877	0.5684	0.3808	0.6346	0.3632	0.4076	0.3687	0.4684	0.5034	0.9105	0.2064	0.3386	0.5741	0.4869	0.2622	0.5796	0.8783	0.0610	0.4409	0.0843	0.5632	0.5393
%];
%z = zz';
%xx = z(1:5);
%yy = z(6:40);
sheet = 1;
k = k+1;
xlrange = xlRange(1,k);
xlswrite(filename1,xx',sheet,xlrange);
xlrange = xlRange(6,k);
xlswrite(filename1,yy',sheet,xlrange);
probname = problem{pro};
addpath(strcat('BOLIBExample/',probname)); 
xlrange = xlRange(1,k);
fprintf('Method 1_LM: i = %2d', i); 
[w,xi,iter,lm_iter,lm_iter_part,term,err1] = Method1_LM(dim,pars,xlrange,xx,yy);
xlrange = xlRange(9,k);
fprintf('Method 1_Res: i = %2d\n', i);
[w_FB_res,xi_FB_res,iter_FB_res,lm_iter_FB,lm_iter_FB_part,term_FB_res,err2] = Method1_LM_FB_residual(dim,pars,xlrange,xx,yy);
xlrange = xlRange(15,k);
fprintf('Method 2_LM: i = %2d',i); 
[w,xi,iter,lm_iter,lm_iter_part,term,err3] = Method2_LM(dim,pars,xlrange,xx,yy);
xlrange = xlRange(21,k);
fprintf('Method 2_Res: i = %2d\n',i); 
[w_FB_res,xi_FB_res,iter_FB_res,lm_iter_FB,lm_iter_FB_part,term_FB_res,err4] = Method2_LM_FB_residual(dim,pars,xlrange,xx,yy);
xlrange = xlRange(27,k);
fprintf('Method 3_LM: i = %2d',i); 
[w,xi,iter,lm_iter,lm_iter_part,term,err5] = Method3_LM(dim,pars,xlrange,xx,yy);
xlrange = xlRange(33,k);
fprintf('Method 2_Res: i = %2d\n',i); 
[w_FB_res,xi_FB_res,iter_FB_res,lm_iter_FB,lm_iter_FB_part,term_FB_res,err6] = Method3_LM_FB_residual(dim,pars,xlrange,xx,yy);

n1 = 1:numel(err1);
n2 = 1:numel(err2);
n3 = 1:numel(err3);
n4 = 1:numel(err4);
n5 = 1:numel(err5);
n6 = 1:numel(err6);

figure(i)
plot(n1,err1,'-b','LineWidth', 2);
hold on
plot(n2,err2,'-r','LineWidth', 2);
plot(n3,err3,'-cy','LineWidth', 2);
plot(n4,err4,'-m','LineWidth', 2);
plot(n5,err5,'-k','LineWidth', 2);
plot(n6,err6,'-g','LineWidth', 2);
hold off
    set(gca,'YScale','log');
    xlabel('Number of iterations');
    ylabel('\|value_{k}\|^2'); %\|H(z^{k},\xi^{k})\|^2 + \|\phi_{FB}(G(z^{k},-\xi^{k})\|^2
    legend('Algorithm 4.5 (Para)','Algorithm 4.10 (Para)','Algorithm 4.5 (Var 1)','Algorithm 4.10 (Var 1)',...
        'Algorithm 4.5 (Var 2)', 'Algorithm 4.5 (Var 2)'); %,'Location','BestOutside'
    title('Case{i}')
    

%fprintf('min-residual: %2d Iterations,  %2d full LM-steps, ',iter,lm_iter);
%fprintf('%2d partial LM-steps, termination due to %2d\n',lm_iter_part,term);
%fprintf('FB-residual: %2d Iterations,  %2d full LM-steps, ',iter_FB_res,lm_iter_FB);
%fprintf('%2d partial LM-steps, termination due to %2d\n',lm_iter_FB_part,term_FB_res);
%fprintf('pure FB-LM: %2d Iterations,  termination due to %2d\n',iter_FB_pure,term_FB_pure);

   
end