function [X,xi,iter,lm_iter_full,lm_iter_part,termination,err2] = Method1_LM_FB_residual(dim,pars,xlrange,xx,yy)

% problem is a struct that should contain:
% - starting value x0
% - objective f
% - inequality constraint g
% - equality constraint h

% termination is set to 0 if maximum number of iterations is hit,
% to 1 if the method terminates due to convergence, and to 2 if
% the method terminates due to stationarity
num    = getnumber(dim);

pars.num = num;
pars.dim = dim;

p1 = dim(1)+dim(2);
p2 = dim(4)+dim(3)+dim(4);

system.H = @H;
system.G = @G;


system.w0 = [xx; yy]; 
system.xi0 = [0.5*ones(dim(4),1); ones(dim(3),1); 0.5*ones(dim(4),1)]; 

termination = 0;
X = system.w0;
xi = system.xi0;

p1 = length(X);
p2 = length(xi);
p = p1+p2;
% algorithm parameters
maxiter = 1000;
q = 0.9;   

%%beta changed

tau_abs = 1e-4; %threshold for termination
tau_abs_stat = 1e-3; %threshold for abort due to potential stationarity 
beta = 0.9; %armijo_backtracking
armijo_maxiter = 700; %maximum of armijo iterations
sigma = 0.4; %armijo_sigma
gamma_1 = 1e-4; %for LM parameter
gamma_2 = 0.05; %for LM parameter
rho = 1e-4; %for angle test



% some output
% fprintf(" i  ||F_FB||     Psi   ||nabla Psi||   LM-step?\n");

% assemble Psi
function [val,grad] = Psi(w,xi,pars)
	[Hval, dHw,dHxi] = H(w,xi,pars);
	[Gval, dG] = G(w,pars);
	[F_FB,DF_FB] = FB(Gval,-xi);
	val = sum(Hval .^2 ) + sum(F_FB .^2);
	grad = [dHw,dHxi]' * Hval;
	grad(1:p1) = grad(1:p1) + dG'*diag(DF_FB(:,1))*F_FB;
	grad(p1+1:p1+p2) = grad(p1+1:p1+p2) - diag(DF_FB(:,2))*F_FB;
end

% assemble FB-residual and its Newton-derivative
    function [res,norm_res,D_res] = res_F_FB(w,xi,pars)
     [Hval, dHw, dHxi] = H(w,xi,pars);
	[Gval, dG] = G(w,pars);
	[F_FB,DF_FB] = FB(Gval,-xi);
    res = [Hval;F_FB];
    norm_res = norm(F_FB);
    D_res = [dHw,dHxi;diag(DF_FB(:,1))*dG,(-1)*diag(DF_FB(:,2))];
    end

%%   Assemble G value and its derivative
function [val,D] = G(X,pars)
dim = pars.dim;
dim0   = [dim(1) dim(2)];
num    = [dim0(1) zeros(1,2)];
for i=2
num(i) = num(i-1)+dim0(i);
end

x     = X(1: num(1),:);
y     = X(num(1)+1:num(2),:);

g   = fun(x,y,'g');
gx  = fun(x,y,'g','x');
gy  = fun(x,y,'g','y');

G   = fun(x,y,'G');
Gx  = fun(x,y,'G','x');
Gy  = fun(x,y,'G','y');




  val = [g; G; g];
     
  D   = [gx, gy;
         Gx, Gy;
         gx, gy];

end





%% Assemble H values and its derivatives wrt w and Lagrange multipliers

    function [val,Dw,Dxi] = H(X,xi,pars)
dim    = pars.dim;
dim0   = [dim(1) dim(2)];
dim1   = [dim(4) dim(3) dim(4)];
num    = [dim0(1) zeros(1,2)];
numm   = [dim1(1) ones(1,3)];
for i=2
num(i) = num(i-1)+dim0(i);
end
for j=2:3
numm(j) = numm(j-1)+dim1(j);    
end


 
x     = X(1: num(1),:);
y     = X(num(1)+1:num(2),:);
lam   = 1;
bet     = xi(1: numm(1),:);
alp     = xi(numm(1)+1:numm(2),:);
bet2     = xi(numm(2)+1:numm(3),:);


Gxyx  = fun(x,y,'G','x');
Gxyy  = fun(x,y,'G','y');
gxyx  = fun(x,y,'g','x');
gxyy  = fun(x,y,'g','y');

 
JLx  = fun(x,y,'F','x') + Gxyx'*alp + ...
       gxyx'*bet - lam^2*gxyx'*bet2;       
JLy  = fun(x,y,'F','y') + Gxyy'*alp + ...
       gxyy'*bet - lam^2*gxyy'*bet2;
   
Jly  = fun(x,y,'f','y') + gxyy'*bet2;

val  = [JLx; JLy; Jly];

JLxx = fun(x,y,'F','xx')  +  JuTf(alp,fun(x,y,'G','xx'))   + ...
       + JuTf(bet,fun(x,y,'g','xx')) - lam*JuTf(bet2,fun(x,y,'g','xx'));
JLxy = fun(x,y,'F','xy')  +  JuTf(alp,fun(x,y,'G','xy'))   + ...
       + JuTf(bet,fun(x,y,'g','xy')) - lam*JuTf(bet2,fun(x,y,'g','xy'));
JLxu = fun(x,y,'G','x');
JLxv = fun(x,y,'g','x');
JLxw = -lam*fun(x,y,'g','x');


JLyy = fun(x,y,'F','yy')  +  JuTf(alp,fun(x,y,'G','yy'))   + ...
       + JuTf(bet,fun(x,y,'g','yy')) - lam*JuTf(bet2,fun(x,y,'g','yy'));
JLyu = fun(x,y,'G','y'); 
JLyv = fun(x,y,'g','y'); 
JLyw = -lam*fun(x,y,'g','y');


Jlxy = fun(x,y,'f','xy') + JuTf(bet2,fun(x,y,'g','xy'));
Jlyy = fun(x,y,'f','yy') + JuTf(bet2,fun(x,y,'g','yy'));
Jlyu = zeros(dim(2),dim(3));
Jlyv = zeros(dim(2),dim(4));
Jlyw = fun(x,y,'g','y');

Dw   = [JLxx, JLxy'; ...
        JLxy, JLyy; ...
        Jlxy, Jlyy];

    
Dxi  = [JLxv' JLxu' JLxw';
        JLyv' JLyu' JLyw';
        Jlyv  Jlyu  Jlyw']; 

end
% ========================================================================
function Juf = JuTf(u,Jf) 
    if ~isempty(Jf)
        nG    = size(u,1);
        nx    = size(Jf,2);
        ny    = size(Jf,1)/nG;
        Juf   = zeros(ny,nx);
        for i = 1:nG
        Juf   = Juf+ u(i)*ones(ny,nx).*Jf( (1+(i-1)*ny):(i*ny),: );
        end
    else
        Juf   = 0;
    end
end


%% Algorithm start

lm_iter_full=0;
lm_iter_part=0;

% loop of the algorithm
tic
err2 = 1;
for iter = 1:maxiter
	
	[old_val_Psi,grad_Psi] = Psi(X,xi,pars);

    [~,norm_res,D_res] = res_F_FB(X,xi,pars);

    if norm_res <= tau_abs
		% fprintf('%2d  %6.3e  converged\n',iter,norm_res^2);
        termination = 1;
		break
    elseif norm(grad_Psi) <= tau_abs_stat
        % fprintf('abort, current iterate stationary for Psi\n');
        termination = 2;
        break
    end

	% assemble LM parameter
    nu = min(gamma_1,gamma_2*norm_res);

	% compute LM-direction    
    dz = (D_res'*D_res + nu * eye(p)) \ ((-1)*grad_Psi);
        
    w_new = X + dz(1:p1);
    xi_new = xi + dz(p1+1:p1+p2);
  
    [new_val_Psi,~]=Psi(w_new,xi_new,pars);
	
    ratio_test = (new_val_Psi <= q* old_val_Psi);

        if ratio_test
            % do full LM step
            X = w_new;
            xi = xi_new;
            lm_iter_full = lm_iter_full+1;
        else

            angle_test = (grad_Psi'*dz<=(-1)*rho*norm(grad_Psi)*norm(dz));

            if ~angle_test
                %gradient step if LM-direction does not satisfy angle test
                dz = -grad_Psi;
            else
                lm_iter_part = lm_iter_part + 1;
            end
                   
        
            alpha = 1;
            descent = grad_Psi'*dz; % should be negative
            for armijo_iter = 1:armijo_maxiter
                w_new = X + alpha*dz(1:p1);
                xi_new = xi + alpha*dz(p1+1:p1+p2);
                [new_val_Psi,~] = Psi(w_new,xi_new,pars);
                if new_val_Psi <= old_val_Psi + sigma*alpha*descent
                    % sufficient decrease achieved
                    break
                end
                alpha = alpha * beta;
            end
            % do gradient step
            X = w_new;
            xi = xi_new;
        end

         err2(iter)= new_val_Psi;
    

    % monitor some information
    % fprintf('%2d  %6.3e   %6.3e   %6.3e     ',iter,norm_res,old_val_Psi,norm_grad_Psi);
	% fprintf('%d\n',ratio_test);

end % LM-Loop

%% End of Algorithm, Write result to Excel file

time = toc;
yo = [ -0.0032,  0.0053, -0.0031,  0.0024,  2.9991,  4.5902,  0.0020, ...
        0.0020,  5.0030,  1.5969, -0.0001,  0.0040,  0.0078,  0.9911, ...
       -0.0080,  0.0030,  3.2053,  0.0098, -0.0075,  4.3973,  0.0035, ...
       -0.0025,  0.0073,  0.1958,  7.3927,  0.0035, -0.0059,  0.0074, ...
        5.0050, -0.0016, -0.0100,  2.5930, -0.0045,  0.0074,  0.0020 ]';
Out_F = 0.5*norm(X(6:40) - yo)^2;
Out_time = time;

table1='Non33c.xlsx';
  T={num2str(iter),num2str(lm_iter_full),num2str(lm_iter_part),num2str(termination),num2str(new_val_Psi),num2str(Out_time),...
      num2str(Out_F)};
  sheet=1;
  xlRange=xlrange;
  xlswrite(table1,T,sheet,xlRange);


end % function
