function [f,derivative] = FB(a,b)
	% derivative format is not jacbian matrix, but coordinate-wise jacobian


	sqrt_term = sqrt(a.^2 + b.^2);

	f = sqrt_term + a + b;

	% derivative is a 
	derivative = [  a ./ sqrt_term + 1  , b ./ sqrt_term + 1 ];

	% to fix NaNs, find coordinates where a=b=0
	I = ~sqrt_term;
	derivative(I,:) = 1;
end
